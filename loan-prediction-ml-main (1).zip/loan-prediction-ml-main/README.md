# loan-prediction-ml
Loan Prediction using Machine Learning (Logistic Regression)
